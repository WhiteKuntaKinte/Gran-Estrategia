"""Traducciones al español. Edita aquí si quieres cambiar algún nombre y vuelve a ejecutar construir_mapa.py
(o edita directamente datos/etiquetas.json y provincias_juego.json si solo quieres retocar un texto)."""

PAISES_ES = {
 'Afghanistan': 'Afganistán', 'Albania': 'Albania', 'Algeria': 'Argelia', 'Angola': 'Angola', 'Antarctica': 'Antártida',
 'Argentina': 'Argentina', 'Armenia': 'Armenia', 'Australia': 'Australia', 'Austria': 'Austria', 'Azerbaijan': 'Azerbaiyán',
 'Bahamas': 'Bahamas', 'Bangladesh': 'Bangladés', 'Belarus': 'Bielorrusia', 'Belgium': 'Bélgica', 'Belize': 'Belice',
 'Benin': 'Benín', 'Bhutan': 'Bután', 'Bolivia': 'Bolivia', 'Bosnia and Herz.': 'Bosnia y Herzegovina', 'Botswana': 'Botsuana',
 'Brazil': 'Brasil', 'Brunei': 'Brunéi', 'Bulgaria': 'Bulgaria', 'Burkina Faso': 'Burkina Faso', 'Burundi': 'Burundi',
 'Cambodia': 'Camboya', 'Cameroon': 'Camerún', 'Canada': 'Canadá', 'Central African Rep.': 'República Centroafricana',
 'Chad': 'Chad', 'Chile': 'Chile', 'China': 'China', 'Colombia': 'Colombia', 'Congo': 'República del Congo',
 'Costa Rica': 'Costa Rica', 'Croatia': 'Croacia', 'Cuba': 'Cuba', 'Cyprus': 'Chipre', 'Czechia': 'Chequia',
 "Côte d'Ivoire": 'Costa de Marfil', 'Dem. Rep. Congo': 'R. D. del Congo', 'Denmark': 'Dinamarca', 'Djibouti': 'Yibuti',
 'Dominican Rep.': 'República Dominicana', 'Ecuador': 'Ecuador', 'Egypt': 'Egipto', 'El Salvador': 'El Salvador',
 'Eq. Guinea': 'Guinea Ecuatorial', 'Eritrea': 'Eritrea', 'España': 'España', 'Estonia': 'Estonia', 'Ethiopia': 'Etiopía',
 'Falkland Is.': 'Islas Malvinas', 'Fiji': 'Fiyi', 'Finland': 'Finlandia', 'Fr. S. Antarctic Lands': 'Tierras Australes Francesas',
 'France': 'Francia', 'Gabon': 'Gabón', 'Gambia': 'Gambia', 'Georgia': 'Georgia', 'Germany': 'Alemania', 'Ghana': 'Ghana',
 'Greece': 'Grecia', 'Greenland': 'Groenlandia', 'Guatemala': 'Guatemala', 'Guinea': 'Guinea', 'Guinea-Bissau': 'Guinea-Bisáu',
 'Guyana': 'Guyana', 'Haiti': 'Haití', 'Honduras': 'Honduras', 'Hungary': 'Hungría', 'Iceland': 'Islandia', 'India': 'India',
 'Indonesia': 'Indonesia', 'Iran': 'Irán', 'Iraq': 'Irak', 'Ireland': 'Irlanda', 'Israel': 'Israel', 'Italy': 'Italia',
 'Jamaica': 'Jamaica', 'Japan': 'Japón', 'Jordan': 'Jordania', 'Kazakhstan': 'Kazajistán', 'Kenya': 'Kenia', 'Kosovo': 'Kosovo',
 'Kuwait': 'Kuwait', 'Kyrgyzstan': 'Kirguistán', 'Laos': 'Laos', 'Latvia': 'Letonia', 'Lebanon': 'Líbano', 'Lesotho': 'Lesoto',
 'Liberia': 'Liberia', 'Libya': 'Libia', 'Lithuania': 'Lituania', 'Luxembourg': 'Luxemburgo', 'Madagascar': 'Madagascar',
 'Malawi': 'Malaui', 'Malaysia': 'Malasia', 'Mali': 'Malí', 'Mauritania': 'Mauritania', 'Mexico': 'México', 'Moldova': 'Moldavia',
 'Mongolia': 'Mongolia', 'Montenegro': 'Montenegro', 'Morocco': 'Marruecos', 'Mozambique': 'Mozambique', 'Myanmar': 'Birmania',
 'N. Cyprus': 'Chipre del Norte', 'Namibia': 'Namibia', 'Nepal': 'Nepal', 'Netherlands': 'Países Bajos',
 'New Caledonia': 'Nueva Caledonia', 'New Zealand': 'Nueva Zelanda', 'Nicaragua': 'Nicaragua', 'Niger': 'Níger',
 'Nigeria': 'Nigeria', 'North Korea': 'Corea del Norte', 'North Macedonia': 'Macedonia del Norte', 'Norway': 'Noruega',
 'Oman': 'Omán', 'Pakistan': 'Pakistán', 'Palestine': 'Palestina', 'Panama': 'Panamá', 'Papua New Guinea': 'Papúa Nueva Guinea',
 'Paraguay': 'Paraguay', 'Peru': 'Perú', 'Philippines': 'Filipinas', 'Poland': 'Polonia', 'Portugal': 'Portugal',
 'Puerto Rico': 'Puerto Rico', 'Qatar': 'Catar', 'Romania': 'Rumanía', 'Russia': 'Rusia', 'Rwanda': 'Ruanda',
 'S. Sudan': 'Sudán del Sur', 'Saudi Arabia': 'Arabia Saudita', 'Senegal': 'Senegal', 'Serbia': 'Serbia',
 'Sierra Leone': 'Sierra Leona', 'Slovakia': 'Eslovaquia', 'Slovenia': 'Eslovenia', 'Solomon Is.': 'Islas Salomón',
 'Somalia': 'Somalia', 'Somaliland': 'Somalilandia', 'South Africa': 'Sudáfrica', 'South Korea': 'Corea del Sur',
 'Sri Lanka': 'Sri Lanka', 'Sudan': 'Sudán', 'Suriname': 'Surinam', 'Sweden': 'Suecia', 'Switzerland': 'Suiza', 'Syria': 'Siria',
 'Taiwan': 'Taiwán', 'Tajikistan': 'Tayikistán', 'Tanzania': 'Tanzania', 'Thailand': 'Tailandia', 'Timor-Leste': 'Timor Oriental',
 'Togo': 'Togo', 'Trinidad and Tobago': 'Trinidad y Tobago', 'Tunisia': 'Túnez', 'Turkey': 'Turquía', 'Turkmenistan': 'Turkmenistán',
 'Uganda': 'Uganda', 'Ukraine': 'Ucrania', 'United Arab Emirates': 'Emiratos Árabes Unidos', 'United Kingdom': 'Reino Unido',
 'United States of America': 'Estados Unidos', 'Uruguay': 'Uruguay', 'Uzbekistan': 'Uzbekistán', 'Vanuatu': 'Vanuatu',
 'Venezuela': 'Venezuela', 'Vietnam': 'Vietnam', 'W. Sahara': 'Sahara Occidental', 'Yemen': 'Yemen', 'Zambia': 'Zambia',
 'Zimbabwe': 'Zimbabue', 'eSwatini': 'Esuatini',
}

PROVINCIAS_ES = {
 # España
 'Castilla-Leon': 'Castilla y León', 'Cataluña': 'Cataluña', 'Andalucia': 'Andalucía', 'Aragon': 'Aragón', 'Pais Vasco': 'País Vasco',
 'Castilla-La Mancha': 'Castilla-La Mancha', 'Valencia': 'Valencia',
 # Estados Unidos
 'District of Columbia': 'Distrito de Columbia', 'New York': 'Nueva York', 'New Jersey': 'Nueva Jersey', 'New Mexico': 'Nuevo México',
 'New Hampshire': 'Nuevo Hampshire', 'North Carolina': 'Carolina del Norte', 'South Carolina': 'Carolina del Sur',
 'North Dakota': 'Dakota del Norte', 'South Dakota': 'Dakota del Sur', 'West Virginia': 'Virginia Occidental', 'Hawaii': 'Hawái',
 'Pennsylvania': 'Pensilvania', 'Louisiana': 'Luisiana', 'Georgia': 'Georgia',
 # Canadá
 'British Columbia': 'Columbia Británica', 'New Brunswick': 'Nuevo Brunswick', 'Newfoundland and Labrador': 'Terranova y Labrador',
 'Nova Scotia': 'Nueva Escocia', 'Northwest Territories': 'Territorios del Noroeste', 'Prince Edward Island': 'Isla del Príncipe Eduardo',
 'Québec': 'Quebec',
 # Australia
 'Western Australia': 'Australia Occidental', 'Northern Territory': 'Territorio del Norte', 'South Australia': 'Australia Meridional',
 'Australian Capital Territory': 'Territorio de la Capital', 'Jervis Bay Territory': 'Bahía Jervis', 'New South Wales': 'Nueva Gales del Sur',
 # Sudáfrica
 'Northern Cape': 'Cabo Septentrional', 'Western Cape': 'Cabo Occidental', 'North West': 'Noroeste', 'Free State': 'Estado Libre',
 'Eastern Cape': 'Cabo Oriental',
 # Rusia (los más conocidos)
 'Moskva': 'Moscú', 'City of St. Petersburg': 'San Petersburgo', 'Moskovskaya': 'Óblast de Moscú', 'Leningrad': 'Leningrado',
 'Arkhangel\'sk': 'Arcángel', 'Sakha (Yakutia)': 'Yakutia', 'Chukchi Autonomous Okrug': 'Chukotka', 'Primor\'ye': 'Primorie',
 'Kaliningrad': 'Kaliningrado', 'Novgorod': 'Nóvgorod', 'Nizhegorod': 'Nizhni Nóvgorod', 'Krasnodar': 'Krasnodar',
 'Maga Buryatdan': 'Magadán', 'Yevrey': 'Óblast Autónomo Judío',
 # China
 'Xizang': 'Tíbet', 'Inner Mongol': 'Mongolia Interior', 'Beijing': 'Pekín',
 # India
 'Delhi': 'Delhi', 'Jammu and Kashmir': 'Jammu y Cachemira',
}
